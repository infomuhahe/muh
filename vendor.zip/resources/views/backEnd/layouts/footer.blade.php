<div class="row-fluid">
    <div id="footer" class="span12">&copy; 2019 K-Super Store All Rights Reserved</div>
</div>