<footer id="footer"><!--Footer-->
    <div id="footer"><!-- #footer Begin -->
        <div class="container"><!-- container Begin -->
            <div class="row"><!-- row Begin -->
                <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                   
                   <h4>Wholesaler Section</h4>
                    
                    <ul><!-- ul Begin -->
                        <li><a href="../contact.php">Login</a></li>
                        <li><a href="../about.php">Register</a></li>
                    </ul><!-- ul Finish -->
                    
                    <hr>
                    
                    <h4>Affliate Section</h4>
                    
                    <ul><!-- ul Begin -->
                        <li><a href="#">Login</a></li>       
                        <li><a href="#">Register</a></li>
                    </ul><!-- ul Finish -->
                    
                    <hr class="hidden-md hidden-lg hidden-sm">
                    
                </div><!-- col-sm-6 col-md-3 Finish -->
                
                <div class="com-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                    
                    <h4>Let Us Help You</h4>
                    
                    <ul><!-- ul Begin -->
                        <li><a href="../cart.php">Payment</a></li>
                        <li><a href="../contact.php">Shipping</a></li>
                        <li><a href="../faq.php">FAQ</a></li>
                        <li><a href="../shop.php">Shopping Cart</a></li>
                        <li><a href="../shop.php">Shop</a></li>

                    </ul><!-- ul Finish -->
                    
                    <hr class="hidden-md hidden-lg hidden-sm">
                    
                </div><!-- col-sm-6 col-md-3 Finish -->
                
                <div class="col-sm-6 col-md-3"><!-- col-sm-6 col-md-3 Begin -->
                    
                    <h4>Find Us</h4>
                    <ul>
                        <li>Muhahe.com</li>
                        <li> Kigali</li>
                        <li>Rwanda</li>
                        <li><b>Email:</b> support@muhahe.com</li>
                        <li><b>Phone:</b> (+250)783524980</li>

                    </ul>
                    {{-- <a href="../contact.php">Check Our Contact Page</a> --}}
                    
                    <hr class="hidden-md hidden-lg">
                </div><!-- col-sm-6 col-md-3 Finish -->
                
                <div class="col-sm-6 col-md-3">
                    
                    <h4>Get The News</h4>
                    
                    <p class="text-muted">
                        Dont miss our latest update products.
                    </p>
                    
                    <form action="" method="post"><!-- form begin -->
                        <div class="input-group"><!-- input-group begin -->
                            
                            <input type="text" class="form-control" name="email">
                            
                            <input type="hidden" value="" name="uri"/><input type="hidden" name="loc" value="en_US"/>
                            
                            <span class="input-group-btn"><!-- input-group-btn begin -->
                                
                                <input type="submit" value="subscribe" class="btn btn-default">
                                
                            </span><!-- input-group-btn Finish -->
                            
                        </div><!-- input-group Finish -->
                    </form><!-- form Finish -->
                    
                    <hr>
                    
                    <h4>Keep In Touch With Us</h4>
                    
                    <p class="social">
                        <a href="../#" class="fa fa-facebook"></a>
                        <a href="../#" class="fa fa-twitter"></a>
                        <a href="../#" class="fa fa-instagram"></a>
                        <a href="../#" class="fa fa-google-plus"></a>
                        <a href="../#" class="fa fa-envelope"></a>
                    </p>
                    
                </div>
            </div><!-- row Finish -->
        </div><!-- container Finish -->
    </div><!-- #footer Finish -->
    
    
    <div id="copyright"><!-- #copyright Begin -->
        <div class="container"><!-- container Begin -->
            <div class="col-md-12"><!-- col-md-6 Begin -->
                
                <p>&copy; 2019 Muhahe.com All Rights Reserved</p>
                
            </div><!-- col-md-6 Finish -->
            {{-- <div class="col-md-6"><!-- col-md-6 Begin -->
                
                <p class="pull-right">Developed by: <a href="#">Donat</a></p>
                
            </div><!-- col-md-6 Finish --> --}}
        </div><!-- container Finish -->
    </div><!-- #copyright Finish -->

</footer><!--/Footer-->