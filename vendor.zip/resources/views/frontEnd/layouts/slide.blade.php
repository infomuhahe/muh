<section id="slide">
<!-- ============== owl slide items 2  ============= -->
<div class="owl-carousel owl-init slide-items" id="slide_custom_nav" data-custom-nav="custom-nav-first" data-items="5" data-margin="20" data-dots="true" data-nav="false">
        <div class="item-slide">
    <figure class="card card-product">
        <span class="badge-new"> NEW </span>
        <div class="img-wrap"> <img src="images/items/1.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">First item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
        <div class="item-slide">
    <figure class="card card-product">
        <div class="img-wrap"> <img src="images/items/2.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">Second item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
        <div class="item-slide">
    <figure class="card card-product">
        <div class="img-wrap"> <img src="images/items/3.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">Third item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
        <div class="item-slide">
    <figure class="card card-product">
        <div class="img-wrap"> <img src="images/items/4.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">Good item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
        <div class="item-slide">
    <figure class="card card-product">
        <div class="img-wrap"> <img src="images/items/5.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">Another item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
        <div class="item-slide">
    <figure class="card card-product">
        <div class="img-wrap"> <img src="images/items/3.jpg"> </div>
        <figcaption class="info-wrap text-center">
            <h6 class="title text-truncate"><a href="#">Third item name</a></h6>
        </figcaption>
    </figure> <!-- card // -->
        </div>
    </div>
    <!-- ============== owl slide items 2 .end // ============= -->
   </section>