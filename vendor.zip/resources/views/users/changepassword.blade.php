@extends('frontEnd.layouts.master')
@section('title','My Account Page')
@section('slider')
@endsection
@section('content')
    <div class="container">
        @if(Session::has('message'))
            <div class="alert alert-success text-center" role="alert">
                {{Session::get('message')}}
            </div>
        @endif
        <div class="row">
                <div class="col-md-3">
                        @include('users.sidebar')
                </div>
            <div class="col-md-9">
                    <div class="box">
                            <h1 align="center"> Change Password </h1>

                            <form action="{{url('/update-password',$user_login->id)}}" method="post"><!-- form Begin -->
                                <input type="hidden" name="_token" value="{{csrf_token()}}">
                                {{method_field('PUT')}}
                                <div class="form-group {{$errors->has('password')?'has-error':''}}" ><!-- form-group Begin -->
        
                                    <label> Your Old Password: </label>
        
                                    <input type="password" class="form-control" name="password" id="password" required>
                                    @if(Session::has('oldpassword'))
                                        <span class="text-danger">{{Session::get('oldpassword')}}</span>
                                    @endif
                                </div><!-- form-group Finish -->
    
                                <div class="form-group  {{$errors->has('newPassword')?'has-error':''}}"><!-- form-group Begin -->
        
                                    <label> Your New Password: </label>
        
                                    <input type="password" class="form-control" name="newPassword" id="newPassword" required>
                                    <span class="text-danger">{{$errors->first('newPassword')}}</span>
                                </div><!-- form-group Finish -->
    
                                <div class="form-group {{$errors->has('newPassword_confirmation')?'has-error':''}}"><!-- form-group Begin -->
        
                                    <label> Confirm Your New Password: </label>
        
                                    <input type="password" class="form-control" name="newPassword_confirmation" id="newPassword_confirmation" required>
                                    <span class="text-danger">{{$errors->first('newPassword_confirmation')}}</span>
                                </div><!-- form-group Finish -->
    
                                <div class="text-center"><!-- text-center Begin -->
        
                                    <button type="submit" name="submit" class="btn btn-primary"><!-- btn btn-primary Begin -->
            
                                        <i class="fa fa-user-md"></i> Update Now
            
                                    </button><!-- btn btn-primary inish -->
        
                                </div><!-- text-center Finish -->
    
                            </form><!-- form Finish -->









                             {{-- <div class="signup-form"><!--sign up form-->
                                <form action="{{url('/update-password',$user_login->id)}}" method="post" class="form-horizontal">
                                    <legend>Update New Password</legend>
                                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                                    {{method_field('PUT')}} 
                                    <div class="form-group {{$errors->has('password')?'has-error':''}}">
                                        <input type="password" class="form-control" name="password" id="password" placeholder="Old Password">
                                        @if(Session::has('oldpassword'))
                                            <span class="text-danger">{{Session::get('oldpassword')}}</span>
                                        @endif
                                    </div> 
                                     <div class="form-group {{$errors->has('newPassword')?'has-error':''}}">
                                        <input type="password" class="form-control" name="newPassword" id="newPassword" placeholder="New Password">
                                        <span class="text-danger">{{$errors->first('newPassword')}}</span>
                                    </div> --
                                    <div class="form-group {{$errors->has('newPassword_confirmation')?'has-error':''}}">
                                        <input type="password" class="form-control" name="newPassword_confirmation" id="newPassword_confirmation" placeholder="Confirm Password">
                                        <span class="text-danger">{{$errors->first('newPassword_confirmation')}}</span>
                                    </div>
                                    <button type="submit" class="btn btn-primary" style="float: right;">Update Password</button>
                                </form>
                            </div><!--/sign up form--> --}}

                </div>
            </div>
        </div>
		
    </div>
    <div style="margin-bottom: 20px;"></div>
@endsection
		