<?php $__env->startSection('title','My Account Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
                <div class="col-md-3">
                        <?php echo $__env->make('users.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            <div class="col-md-9">
                    <div class="box">
                            <h1 align="center"> Change Password </h1>

                            <form action="<?php echo e(url('/update-password',$user_login->id)); ?>" method="post"><!-- form Begin -->
                                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                <?php echo e(method_field('PUT')); ?>

                                <div class="form-group <?php echo e($errors->has('password')?'has-error':''); ?>" ><!-- form-group Begin -->
        
                                    <label> Your Old Password: </label>
        
                                    <input type="password" class="form-control" name="password" id="password" required>
                                    <?php if(Session::has('oldpassword')): ?>
                                        <span class="text-danger"><?php echo e(Session::get('oldpassword')); ?></span>
                                    <?php endif; ?>
                                </div><!-- form-group Finish -->
    
                                <div class="form-group  <?php echo e($errors->has('newPassword')?'has-error':''); ?>"><!-- form-group Begin -->
        
                                    <label> Your New Password: </label>
        
                                    <input type="password" class="form-control" name="newPassword" id="newPassword" required>
                                    <span class="text-danger"><?php echo e($errors->first('newPassword')); ?></span>
                                </div><!-- form-group Finish -->
    
                                <div class="form-group <?php echo e($errors->has('newPassword_confirmation')?'has-error':''); ?>"><!-- form-group Begin -->
        
                                    <label> Confirm Your New Password: </label>
        
                                    <input type="password" class="form-control" name="newPassword_confirmation" id="newPassword_confirmation" required>
                                    <span class="text-danger"><?php echo e($errors->first('newPassword_confirmation')); ?></span>
                                </div><!-- form-group Finish -->
    
                                <div class="text-center"><!-- text-center Begin -->
        
                                    <button type="submit" name="submit" class="btn btn-primary"><!-- btn btn-primary Begin -->
            
                                        <i class="fa fa-user-md"></i> Update Now
            
                                    </button><!-- btn btn-primary inish -->
        
                                </div><!-- text-center Finish -->
    
                            </form><!-- form Finish -->









                             

                </div>
            </div>
        </div>
		
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
		
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>