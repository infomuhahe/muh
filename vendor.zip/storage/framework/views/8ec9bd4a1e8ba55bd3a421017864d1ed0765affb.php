<?php $__env->startSection('title','My Account Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
                <div class="col-md-3">
                        <?php echo $__env->make('users.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            <div class="col-md-9">
                    <div class="box">
                   
                        <h1 align="center"> Edit Your Account </h1>

                        <form action="<?php echo e(url('/update-profile',$user_login->id)); ?>" method="post" enctype="multipart/form-data"><!-- form Begin -->
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <?php echo e(method_field('PUT')); ?>

                            <div class="form-group <?php echo e($errors->has('name')?'has-error':''); ?>"><!-- form-group Begin -->
                
                                <label> Costumer Name: </label>
                
                                <input type="text" name="name" class="form-control" value="<?php echo e($user_login->name); ?>" id="name" required>
                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                            </div><!-- form-group Finish -->
           
                            <div class="form-group <?php echo e($errors->has('address')?'has-error':''); ?>"><!-- form-group Begin -->
                
                                <label> Customer Address: </label>
                
                                <input type="text"class="form-control" value="<?php echo e($user_login->address); ?>" name="address" id="address" required>
                                 <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                
                            </div><!-- form-group Finish -->
            
                            <div class="form-group <?php echo e($errors->has('city')?'has-error':''); ?>"><!-- form-group Begin -->
                
                                <label> Customer City: </label>
                
                                <input type="text" class="form-control" name="city" value="<?php echo e($user_login->city); ?>" id="city" required>
                                    <span class="text-danger"><?php echo e($errors->first('city')); ?></span>
                            </div><!-- form-group Finish -->
            
            
                            <div class="form-group <?php echo e($errors->has('state')?'has-error':''); ?>"><!-- form-group Begin -->
                
                                <label> Customer State </label>
                
                                <input type="text" class="form-control" name="state" value="<?php echo e($user_login->state); ?>" id="state" required>
                                <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
                            </div><!-- form-group Finish -->
            
                            <div class="form-group"><!-- form-group Begin -->
                
                                <label> Costumer Country: </label>
                
                                <select name="country" id="country" class="form-control">
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($country->country_name); ?>" <?php echo e($user_login->country==$country->country_name?' selected':''); ?>><?php echo e($country->country_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                
                            </div><!-- form-group Finish -->

                            <div class="form-group <?php echo e($errors->has('mobile')?'has-error':''); ?>"><!-- form-group Begin -->
                
                                <label> Customer Contact: </label>
                
                                <input type="text" class="form-control" name="mobile" value="<?php echo e($user_login->mobile); ?>" id="mobile" required>
                                    <span class="text-danger"><?php echo e($errors->first('mobile')); ?></span>
                            </div><!-- form-group Finish -->
 
                            <div class="text-center"><!-- text-center Begin -->
                
                                <button type="submit" name="update" class="btn btn-primary"><!-- btn btn-primary Begin -->
                    
                                    <i class="fa fa-user-md"></i> Update Now
                    
                                </button><!-- btn btn-primary inish -->
                
                            </div><!-- text-center Finish -->
            
                        </form><!-- form Finish -->
                 </div>
            </div>
        </div>
		
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
		
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>